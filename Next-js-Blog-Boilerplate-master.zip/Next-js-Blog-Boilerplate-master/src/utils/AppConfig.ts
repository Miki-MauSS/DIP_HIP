export const AppConfig = {
  site_name: 'Starter',
  title: 'Next.js Boilerplate',
  description:
    'Starter code for your Next.js blog Boilerplate with Tailwind CSS',
  url: 'https://example.com',
  locale: 'en',
  author: 'Anonymous',
  pagination_size: 5,
};
