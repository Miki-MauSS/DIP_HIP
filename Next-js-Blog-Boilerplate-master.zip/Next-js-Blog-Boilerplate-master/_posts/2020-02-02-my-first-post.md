---
title: 'My first post'
description: Lorem ipsum dolor sit amet, consectetur adipiscing elit.
date: '2020-02-02'
modified_date: '2020-02-02'
image: /assets/images/posts/random-img.jpg
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Example with image:

![Error](@@baseUrl@@/assets/images/posts/error.png)

Example code block:

```js
function myFunction() {
  return true;
}
```
