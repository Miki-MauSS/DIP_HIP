---
title: 'My forth post'
description: Lorem ipsum dolor sit amet, consectetur adipiscing elit.
date: '2020-07-07'
modified_date: '2020-07-07'
image: /assets/images/posts/random-img.jpg
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Example with image:

![Error](@@baseUrl@@/assets/images/posts/error.png)

Example code block:

```js
function myFunction() {
  return true;
}
```
